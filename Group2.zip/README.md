# Optimization and Simulation Project: Restaurant Design
## Project Structure

The .zip file contains two directories Optimization and Simulation with the following main structure.

<u>Optimization</u>

- `Optimization_Main2.m`. The main script which runs the VNS optimization by calling the discrete event simulation a number of times. It uses the default seating policy. The file `VNS.m` is used.
- `Optimization_Main2_Reservation`. The main script which runs the same as above but with seating policy 2.
- `Optimization_MainVNS`. The main script which runs the baseline VNS optimization with the default seating policy.
- `Optimization_MainVNS_Reservation`. The main script which runs the baseline VNS optimization with seating policy 2.
- `table_XXXXX.m`. All files of this naming convention are neighborhood structures used in the VNS as part of both the baseline and golden section VNS approaches.

<u>Simulation</u>

- `Simulation_Main.m`. The main script which runs the discrete event simulation a number of times and plots various indicators. It needs the user to specify a table arrangement as a column vector.
- `Simulation_Main_VarRed.m`. The main script which runs the discrete event simulation while using the control variate method on profit.
- `Simulation_Main_VarRed_Reservation.m`. The main script which runs the discrete event simulation while using the control variate method on profit and using seating policy 2.